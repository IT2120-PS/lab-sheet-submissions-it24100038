setwd("C:\\Users\\CHAMODDEALWIS\\OneDrive - Sri Lanka Institute of Information Technology\\SLIIT\\2nd Year\\1st Sem\\PS\\labs\\Lab 4")

#1
branch_data <- read.table("Exercise.txt", header = TRUE, sep = ",")

#3
boxplot(branch_data$Sales_X1,
        main = "Box Plot for Sales",
        horizontal = TRUE)

#4
#five number summery
summary(branch_data$Advertising_X2)

#IQR
IQR(branch_data$Advertising_X2)

#5


get_outliers <- function(x) {
  q1 <- quantile(x, 0.25)
  q3 <- quantile(x, 0.75)
  iqr <- q3 - q1
  lb <- q1 - 1.5 * iqr
  ub <- q3 + 1.5 * iqr
  outliers <- x[x < lb | x > ub]
  return(outliers)
}

# Check for outliers in Years_X3
get_outliers(branch_data$Years_X3)